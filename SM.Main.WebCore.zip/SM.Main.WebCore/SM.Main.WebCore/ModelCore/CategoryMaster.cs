﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SM.Main.WebCore.ModelCore
{
    public class CategoryMaster
    {
        [Key]
        public int CategoryID { get; set; }

        [Required]
        [Display(Name = "CategoryName")]
        public string CategoryName { get; set; }
        public bool CategoryBasedDiscount { get; set; }
    }
}
