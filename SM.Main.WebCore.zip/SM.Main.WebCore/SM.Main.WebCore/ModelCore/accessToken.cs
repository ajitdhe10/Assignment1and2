﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SM.Main.WebCore.ModelCore
{
    public class accessToken
    {
        public string User_Id { get; set; }
        public string access_token { get; set; }
        //public int access_token_expires_in { get; set; }
        //public int access_token_counter { get; set; }
    }
}
