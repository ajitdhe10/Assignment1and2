﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace SM.Main.WebCore.ModelCore
{
    public class WebAPIResponseSuccess
    {
        public string Status { get; set; }
    }
    public class WebAPIResponse
    {
        public string Message { get; set; }
        public bool IsError { get; set; }
        public object Record { get; set; }
    }
    public class Responses
    {
        public int Status { get; set; }
        public string Message { get; set; }
        public object Record { get; set; }
    }
}
