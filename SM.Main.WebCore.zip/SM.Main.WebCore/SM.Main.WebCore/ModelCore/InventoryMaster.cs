﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SM.Main.WebCore.ModelCore
{
    public class InventoryMaster
    {
        [Key]
        public int InventoryID { get; set; }

        [Required]
        [Display(Name = "ItemName")]
        public string ItemName { get; set; }

        [Required]
        [Display(Name = "StockQty")]
        public int StockQty { get; set; }

        [Required]
        [Display(Name = "ReorderQty")]
        public int Price { get; set; }

        public int CategoryID { get; set; }
    }
}
