﻿using LF.PREMain.MVCCore.Config;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using SM.Main.WebCore.ApiHelpers;
using SM.Main.WebCore.ModelCore;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SM.Main.WebCore.Controllers
{
    public class InventoryController : Controller
    {

        // GET: Country
        public InventoryController()
        {
            ApiHelper.InitializeClient();
        }

        public ActionResult Inventory()
        {
                return View();
        }
        [HttpPost]
        public Responses SaveItem(InventoryMaster inventoryMaster)
        {

            Responses response = new Responses();
            try
            {
                response = SaveItemInfo(inventoryMaster).Result;
            }
            catch (Exception ex)
            {
                response.Status = 0;
            }
            return response;
        }
        public Responses SearchCategoryCode(string categoryId)
        {
            Responses response = new Responses();
            try
            {
                categoryId = (categoryId == null ? "" : categoryId);

                response = SearchByCategory(categoryId).Result;
            }
            catch (Exception ex)
            {
                response.Status = 0;
            }

            return response;
        }

        public Responses GetCountryById(int InventoryId)
        {
            Responses response = new Responses();
            try
            {
                response = GetItemdetails(InventoryId).Result;
            }
            catch (Exception ex)
            {
                response.Status = 0;
            }
            return response;
        }

        public async Task<Responses> SearchByCategory(string categoryId)
        {
            Responses res_obj = new Responses();
            try
            {
                var content = new StringContent("", Encoding.UTF8, "application/json");
                using (HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync(RestApiConfig.itemsList + categoryId))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {

                    }
                    if (response.IsSuccessStatusCode)
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        List<InventoryMaster> _list = new List<InventoryMaster>();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        if (result.IsError)
                        {
                            res_obj.Status = 0;
                            res_obj.Record = null;
                            res_obj.Message = result.Message;
                        }
                        else
                        {
                            _list = JsonConvert.DeserializeObject<List<InventoryMaster>>(result.Record.ToString());
                            res_obj.Status = 1;
                            res_obj.Record = _list;
                            res_obj.Message = result.Message;
                        }
                        return res_obj;
                    }
                    else
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        if (result.IsError)
                        {
                            res_obj.Status = 0;
                            res_obj.Record = null;
                            res_obj.Message = result.Message;
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                res_obj.Status = 0;


            }
            return res_obj;

        }

        public async Task<Responses> GetItemdetails(int Id)
        {
            Responses res_obj = new Responses();
            try
            {
                var content = new StringContent("", Encoding.UTF8, "application/json");
                using (HttpResponseMessage response = await ApiHelper.ApiClient.GetAsync(RestApiConfig.GetById + Id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {

                    }
                    if (response.IsSuccessStatusCode)
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        //List<CurrencyDisplay> _list = new List<CurrencyDisplay>();
                        InventoryMaster _list = new InventoryMaster();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        if (result.IsError)
                        {
                            res_obj.Status = 0;
                            res_obj.Record = null;
                            res_obj.Message = result.Message;
                        }
                        else
                        {
                            _list = JsonConvert.DeserializeObject<InventoryMaster>(result.Record.ToString());
                            res_obj.Status = 1;
                            res_obj.Record = _list;
                            res_obj.Message = result.Message;
                        }
                        return res_obj;
                    }
                    else
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        if (result.IsError)
                        {
                            res_obj.Status = 0;
                            res_obj.Record = null;
                            res_obj.Message = result.Message;
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                res_obj.Status = 0;


            }
            return res_obj;
        }

        public async Task<Responses> SaveItemInfo(InventoryMaster inventoryMaster)
        {

            Responses res_obj = new Responses();
            try
            {
                using (HttpResponseMessage response = ApiHelper.ApiClient.PutAsJsonAsync<InventoryMaster>(RestApiConfig.updateInvent, inventoryMaster).Result)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        //LogoutonUnAuthorizedAccess();
                        //return;
                        // return ff;
                        res_obj.Status = 0;
                        res_obj.Message = "UnAuthorizedAccess";
                        return res_obj;
                    }
                    if (response.IsSuccessStatusCode)
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        res_obj.Status = 1;
                        res_obj.Message = result.Message;
                        //res_obj.Record = _model;
                        return res_obj;
                    }
                    else
                    {
                        var content1 = (response.Content);
                        WebAPIResponse result = new WebAPIResponse();
                        result = await (response.Content.ReadAsAsync<WebAPIResponse>());
                        if (result.IsError)
                        {
                            res_obj.Status = 0;
                            res_obj.Record = null;
                            res_obj.Message = result.Message;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                res_obj.Status = 0;
            }
            return res_obj;
        }
    }
}