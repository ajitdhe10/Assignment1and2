﻿function getDateFormat(date) {
    var dateValue = date.split('-');
    var newDate = dateValue[1] + '/' + dateValue[0] + '/' + dateValue[2];
    return newDate;
}
function getOnlyNumber(id,event) {
     $(id).val($(id).val().replace(/[^0-9]/g, ''));
        if ((event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
 }
function onTextChange(id, event) {
    if ($(id).val().trim() != "") {
        $("#lblTxtChange").val("true");
    }
}
function clearTextChange() {
    $("#lblTxtChange").val("false");
}
function dateKeyPress(id, event) {
    return false;
}
//$("#date").on("keypress keyup blur", function (event) {
//    return false;
//});


//For menu click confirmation box.
function onMenuBack(url) {
    if (checkDataExists()) {
        showConfirmationPopup(url);
        return false;
    }
    else {
        clearTextChange();
        window.location.href = url;
    }

    function checkDataExists() {
        if ($("#lblTxtChange").val() == "true") {
            return true;
        }
        else {
            return false;
        }
    }
}