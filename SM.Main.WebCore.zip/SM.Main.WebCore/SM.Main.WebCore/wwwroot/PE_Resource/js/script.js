﻿//SEARCH PAGINATION
  pageSize = 5;
  pageCount = $("#searchResult").length;

  showPage = function(page) {
      $("#searchResult tbody tr").hide();
      $("#searchResult tbody tr").each(function(n) {
          if (n >= pageSize * (page - 1) && n < pageSize * page)
              $(this).show();
      });
  }

  showPage(1);

  $("#searchPagination li a").click(function() {
      $("#searchPagination li a").removeClass("active");
      $(this).addClass("active");
      showPage(parseInt($(this).text()))
  });
      $('.page-link.prevItem, .page-link.nextItem').click(function(){
      var a = $(this),
          current = $('#searchPagination li active'),
          page = parseInt(current.text());
          console.log(page);
      if (a.hasClass('prevItem')) {
          page--;
          if (page < 1) page = 1;
      } else if (a.hasClass('nextItem')) {
          page++;
          if (page > pageCount) page = pageCount;
      }
 
      $($('#searchPagination li a')[page- 1]).click();
  });