﻿
function showPassword() {
    if ($("#emp-password").val().length > 0) {
        var x = document.getElementById("emp-password");
        if (x.type == "text") {
            x.type = "password";
            //$("#passwordIcon").removeClass("lnr lnr166");
            //$("#passwordIcon").addClass("fa-eye");
        } else {
            x.type = "text";
            //$("#passwordIcon").removeClass("fa-eye");
            //$("#passwordIcon").addClass("lnr lnr166");
        }
    }
}
function showResetPassword() {
    if ($("#resetPassword").val().length > 0) {
        var x = document.getElementById("resetPassword");
        if (x.type == "text") {
            x.type = "password";
            //$("#passwordIcon").removeClass("lnr lnr166");
            //$("#passwordIcon").addClass("fa-eye");
        } else {
            x.type = "text";
            //$("#passwordIcon").removeClass("fa-eye");
            //$("#passwordIcon").addClass("lnr lnr166");
        }
    }
}

function showConfirmPassword() {
    if ($("#empConfirmPass").val().length > 0) {
        var x = document.getElementById("empConfirmPass");
        if (x.type == "text") {
            x.type = "password";
            //$("#passwordIcon").removeClass("lnr lnr166");
            //$("#passwordIcon").addClass("fa-eye");
        } else {
            x.type = "text";
            //$("#passwordIcon").removeClass("fa-eye");
            //$("#passwordIcon").addClass("lnr lnr166");
        }
    }
}




