﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace LF.PREMain.MVCCore.Config
{
    public class RestApiConfig
    {

        //Local
        //public static string EndPoint = "http://localhost:64704/";
        //public static string ApiKeyValue { get { return "OCuED5fcxFU7cgjusr6vlEi3KwGvSNyA"; } }
        //public static string UserName = "ajit";
        //public static string Password = "ajit@123";

        // Constants
        // Security Token Constants
        public static string ApiKey = "ApiKey";
        public static string APIUserTokenKey { get { return "Authorization"; } }
        public static string APIUserTokenValue { get; set; }

        // Error handling Constants
        public static string DefaultHandledExceptionError = "An internal error has occurred";
        public static string DefaultUnprocessableResponseErrorMessage = "Something went wrong";

        // Endpoints
        public static string Login = "api/login";
        public static string WebLogin = "api/Weblogin";
        public static string itemsList = "manager/Store/v1/ManageInventory/get/";
        public static string updateInvent = "manager/Store/v1/ManageInventory/update";
        public static string GetById = "manager/Store/v1/ManageInventory/getbyid/";

    }

}


