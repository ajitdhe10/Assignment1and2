﻿
using LF.PREMain.MVCCore.Config;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SM.Main.WebCore.ApiHelpers
{
    public static class ApiHelper
    {
        public static HttpClient ApiClient { get; set; }
        public static void InitializeClient()
        {
            try
            {
                ApiClient = new HttpClient();
                ApiClient.BaseAddress = new System.Uri("http://localhost:64704/");
                ApiClient.DefaultRequestHeaders.Accept.Clear();
                ApiClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                ApiClient.DefaultRequestHeaders.Remove("Authorization");
                ApiClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(Convert.ToString("Storemanagement"));
            }
            catch(Exception ex)
            {

            }
        
        }
    }
}
