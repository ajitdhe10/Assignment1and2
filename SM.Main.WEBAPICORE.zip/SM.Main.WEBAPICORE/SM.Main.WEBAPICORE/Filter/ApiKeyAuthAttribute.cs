﻿using SM.Main.WEBAPICORE.BusinessLogicCore;
using SM.Main.WEBAPICORE.ModelCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SM.Main.WEBAPICORE.Filter
{
    public class ApiKeyAuthAttribute : Attribute, IAsyncActionFilter
    {
        int _authType = 0;//use authType 1 for Login and get access token , authType 2 for Normal api requests,3 For WebLogin Api.
        public ApiKeyAuthAttribute(int authType)
        {
            _authType = authType;
        }
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            //Custom Authentication using Customer Secert Key and UserName,Password
            VerifyUserDA objVerifyUserDA = new VerifyUserDA();
            if (_authType == 1)
            {
                if (!context.HttpContext.Request.Headers.TryGetValue("CustomerSecretKey", out var CustomerKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "Error: Customer Secret Key is required!",
                        StatusCode = 401
                    }; return;
                }

                //if (!context.HttpContext.Request.Headers.TryGetValue("APIKey", out var APIKey))
                //{ context.Result = new ContentResult() { Content = "API Key is required!", StatusCode = 401};return;}
                //if (!context.HttpContext.Request.Headers.TryGetValue("APIApplicationId", out var APIApplicationId))
                //{context.Result = new ContentResult(){ Content = "APIApplicationId is required!",StatusCode = 401}; return;}

                if (!context.HttpContext.Request.Headers.TryGetValue("UserName", out var UserNameKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "UserName is required!",
                        StatusCode = 401
                    }; return;
                }
                if (!context.HttpContext.Request.Headers.TryGetValue("Password", out var PasswordKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "Password is required!",
                        StatusCode = 401
                    }; return;
                }

                //Authenticate Keys and U-P from DB.
                UserModel objUserModel = new UserModel();
                objUserModel.CustomerSecret = CustomerKey; //useruniquekey--
                objUserModel.UserName = UserNameKey;
                objUserModel.Password = PasswordKey;
                objUserModel = objVerifyUserDA.verifyuserKey(objUserModel);
                //objUserModel = objVerifyUserDA.verifyuserKey(objUserModel, CustomerKey, UserNameKey, PasswordKey);

                if (objUserModel.UserId <= 0)
                {
                    context.Result = new ContentResult()
                    {
                        Content = objUserModel.Message,
                        StatusCode = 401
                    }; return;
                }
                else
                {
                    context.HttpContext.Request.Headers.Add("UserId", objUserModel.UserId.ToString());
                }
            }
            //below block check for the login and password first without CustomerSecretKey for weblogin,
            //if customer Key is not provided from Web Project End.
            else if (_authType == 3)
            {
                if (!context.HttpContext.Request.Headers.TryGetValue("UserName", out var UserNameKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "UserName is required!",
                        StatusCode = 401
                    }; return;
                }
                if (!context.HttpContext.Request.Headers.TryGetValue("Password", out var PasswordKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "Password is required!",
                        StatusCode = 401
                    }; return;
                }

                UserModel objUserModel_web = new UserModel();
               
                // objUserModel_web.CustomerSecret = CustomerKey; //useruniquekey--
                objUserModel_web.UserName = UserNameKey;
                objUserModel_web.Password = PasswordKey;
                objUserModel_web = objVerifyUserDA.VerifyUserNamePassword(objUserModel_web);

                //objUserModel = objVerifyUserDA.verifyuserKey(objUserModel, CustomerKey, UserNameKey, PasswordKey);

                if (objUserModel_web.UserId <= 0)
                {
                    context.Result = new ContentResult()
                    {
                        Content = objUserModel_web.Message,
                        StatusCode = 401
                    }; return;
                }
                else
                {
                    context.HttpContext.Request.Headers.Add("CustomerSecretKey", objUserModel_web.CustomerSecret.ToString());
                }

                if (!context.HttpContext.Request.Headers.TryGetValue("CustomerSecretKey", out var CustomerKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "Error: Customer Secret Key is required!",
                        StatusCode = 401

                    }; return;
                }

                //if (!context.HttpContext.Request.Headers.TryGetValue("APIKey", out var APIKey))
                //{ context.Result = new ContentResult() { Content = "API Key is required!", StatusCode = 401};return;}
                //if (!context.HttpContext.Request.Headers.TryGetValue("APIApplicationId", out var APIApplicationId))
                //{context.Result = new ContentResult(){ Content = "APIApplicationId is required!",StatusCode = 401}; return;}

                //Authenticate Keys and U-P from DB.
                UserModel objUserModel = new UserModel();
                objUserModel.CustomerSecret = CustomerKey; //useruniquekey--
                objUserModel.UserName = UserNameKey;
                objUserModel.Password = PasswordKey;
                objUserModel = objVerifyUserDA.verifyuserKey(objUserModel);
                //objUserModel = objVerifyUserDA.verifyuserKey(objUserModel, CustomerKey, UserNameKey, PasswordKey);

                if (objUserModel.UserId <= 0)
                {
                    context.Result = new ContentResult()
                    {
                        Content = objUserModel.Message,
                        StatusCode = 401
                    }; return;
                }
                else
                {
                    context.HttpContext.Request.Headers.Add("UserId", objUserModel.UserId.ToString());
                }
            }
            //Authorization for Api methos Request, using Token in  Authorization Header .
            else
            {
                //Pass Token in "Authorization" header.
                if (!context.HttpContext.Request.Headers.TryGetValue("Authorization", out var PotentialApiKey))
                {
                    context.Result = new ContentResult()
                    {
                        Content = "You are unauthorized!!",
                        StatusCode = 401
                    }; return;
                }

                //if (!context.HttpContext.Request.Headers.TryGetValue("access_token_counter", out var tokencounter)){context.Result = new ContentResult() {Content = "You are unauthorized!!", StatusCode = 401};return;}

                //Verify Authorization token from DB.
                UserModel objUserModel = new UserModel();

                //custom code just to use for the assignment
                if (PotentialApiKey != "Storemanagement")
                {
                    context.Result = new ContentResult()
                    {
                        Content = objUserModel.Message,//Set message after verify .
                        StatusCode = 401
                    };
                    return;
                }

                //objUserModel.accessToken = PotentialApiKey.ToString().Split()[1];
                //objUserModel.UserId = objVerifyUserDA.verifyAccessToken(objUserModel).UserId;
                //if (objUserModel.UserId <= 0)
                //{
                //    context.Result = new ContentResult()
                //    {
                //        Content = objUserModel.Message,//Set message after verify .
                //        StatusCode = 401
                //    }; 
                //    return;
                //}
            }
            await next(); //If all verification is successful then move to API Methods
        }
    }
}
