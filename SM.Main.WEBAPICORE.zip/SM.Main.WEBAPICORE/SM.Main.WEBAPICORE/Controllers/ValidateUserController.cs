﻿using Microsoft.AspNetCore.Mvc;
using SM.Main.WEBAPICORE.BusinessLogicCore;
using SM.Main.WEBAPICORE.Filter;
using SM.Main.WEBAPICORE.ModelCore;

namespace SM.Main.WEBAPICORE.Controllers.USerValidationLayer
{
    [ApiController]
    public class ValidateUserController : ControllerBase
    {
        //private IVerifyUserDA _IVerifyUserDA;
        /// <summary>
        /// Authentication API with customer secret key and username & password.
        /// And return back the access token after authentication.
        /// response: accessToken model .
        /// </summary>
        [ApiKeyAuth(1)]
        [Route("api/login")]
        [AcceptVerbs("GET")]
        public IActionResult gettoken()
        {
            try
            {
                this.HttpContext.Request.Headers.TryGetValue("CustomerSecretKey", out var CustomerKey);
                this.HttpContext.Request.Headers.TryGetValue("UserName", out var UserName);
                this.HttpContext.Request.Headers.TryGetValue("Password", out var Password);
                this.HttpContext.Request.Headers.TryGetValue("UserId", out var UserId);
                VerifyUserDA objVerifyUserDA = new VerifyUserDA();
                UserModel objUserModel = new UserModel();
                objUserModel.CustomerSecret = CustomerKey;
                objUserModel = objVerifyUserDA.getAccessToken(objUserModel, UserId, CustomerKey);
                accessToken accessToken = new accessToken();
                if (objUserModel.UserId > 0)
                {
                    string ency_UserId = WEBAPICORE.BusinessLogicCore.VerifyUserDA.subEncryption(UserId,
                                                 "", true);
                    accessToken.User_Id = UserId;
                    accessToken.access_token = objUserModel.accessToken;
                    return this.Ok(accessToken);
                }
                return this.BadRequest("InValid Credentials.");
            }
            catch (Exception ex)
            {
                string exception;
                exception = ex.ToString();
            }
            return this.BadRequest("InValid Credentials.");
        }

        /// <summary>
        /// Authentication API with username & password and without customer secret key.From weblogin
        /// And return back the access token after authentication.
        /// response: accessToken model.
        /// Date:14-15-2020
        /// </summary>
        [ApiKeyAuth(3)]
        [Route("api/weblogin")]
        [AcceptVerbs("GET")]
        public IActionResult gettoken_WebLogin()
        {
            try
            {
            this.HttpContext.Request.Headers.TryGetValue("CustomerSecretKey", out var CustomerKey);
            this.HttpContext.Request.Headers.TryGetValue("UserName", out var UserName);
            this.HttpContext.Request.Headers.TryGetValue("Password", out var Password);
            this.HttpContext.Request.Headers.TryGetValue("UserId", out var UserId);
            string ency_UserId = WEBAPICORE.BusinessLogicCore.VerifyUserDA.subEncryption(UserId,
                                             "", true);
            VerifyUserDA objVerifyUserDA = new VerifyUserDA();
            UserModel objUserModel = new UserModel();
            objUserModel.CustomerSecret = CustomerKey;
            objUserModel = objVerifyUserDA.getAccessToken(objUserModel, UserId, CustomerKey);
            accessToken accessToken = new accessToken();
            if (objUserModel.UserId > 0)
            {
                accessToken.User_Id = UserId;
                accessToken.access_token = objUserModel.accessToken;
                return this.Ok(accessToken);
            }
            return this.BadRequest("InValid Credentials.");
            }
            catch (Exception ex)
            {
                string exception;
                exception = ex.ToString();
            }
            return this.BadRequest("InValid Credentials.");
        }
    }
}