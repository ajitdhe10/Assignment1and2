﻿using SM.Main.WEBAPICORE.Services;
using Microsoft.AspNetCore.Mvc;
using PdfSharp.Pdf;
using SM.Main.WEBAPICORE.Filter;
using SM.Main.WEBAPICORE.ModelCore;
using Swashbuckle.Swagger.Annotations;
using TheArtOfDev.HtmlRenderer.PdfSharp;

namespace SM.Main.WEBAPICORE.Controllers
{
    [ApiController]
    public class ManageInventoryController : ControllerBase
    {
        WebAPIResponse webAPIResponse = new WebAPIResponse();
        public ManageInventoryController(IManageInventoryDA ManageInventoryDA)
        {
            this.ManageInventoryDA = ManageInventoryDA ?? throw new ArgumentNullException(nameof(ManageInventoryDA));
        }

        public IManageInventoryDA ManageInventoryDA
        {
            get;
        }

        /// <summary>
        /// Get items by category Id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ApiKeyAuth(2)]//"authkey: Storemanagement"
        [HttpGet("manager/Store/v{version:apiVersion}/ManageInventory/get/{id}")]
        [SwaggerResponse(201, "All operations in the put document succeeded.")]
        [SwaggerResponse(400, "The request could not be processed by the server. This may be due to malformed syntax or a semantic error (e.g., they failed validation for length, range, etc.). Check your parameters and retry.")]
        [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
        [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
        [SwaggerResponse(404, "The requested entity was not found.")]
        [SwaggerResponse(422, "The server understands the content type of the request entity, but it was unable to process the contained instructions.")]
        public IActionResult GetItems(int id)
        {
            Responses response = new Responses();
            InventoryMaster country = new InventoryMaster();
            try
            {
                if (id <= 0)
                {
                    webAPIResponse.IsError = true;
                    webAPIResponse.Message = "The category name field is required ";
                    return BadRequest(webAPIResponse);
                }
                response = ManageInventoryDA.getInventoryBasedOnCatogory(id);
                if (response.Status == 0)
                {
                    webAPIResponse.IsError = true;
                    webAPIResponse.Message = response.Message;

                    return BadRequest(webAPIResponse);

                }
                else
                {
                    webAPIResponse.IsError = false;
                    webAPIResponse.Message = response.Message;
                    webAPIResponse.Record = response.Record;
                    return Ok(webAPIResponse);
                }
            }
            catch (Exception ex)
            {
                webAPIResponse.IsError = false;
                webAPIResponse.Message = "Something went wrong";
                return BadRequest(webAPIResponse);
            }

        }

        /// <summary>
        /// Get items by Inventory Id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ApiKeyAuth(2)]//"authkey: Storemanagement"
        [HttpGet("manager/Store/v{version:apiVersion}/ManageInventory/getbyid/{inventoryId}")]
        [SwaggerResponse(201, "All operations in the put document succeeded.")]
        [SwaggerResponse(400, "The request could not be processed by the server. This may be due to malformed syntax or a semantic error (e.g., they failed validation for length, range, etc.). Check your parameters and retry.")]
        [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
        [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
        [SwaggerResponse(404, "The requested entity was not found.")]
        [SwaggerResponse(422, "The server understands the content type of the request entity, but it was unable to process the contained instructions.")]
        public IActionResult GetItemsByinventoryId(int inventoryId)
        {
            Responses response = new Responses();
            InventoryMaster country = new InventoryMaster();
            try
            {
                if (inventoryId <= 0)
                {
                    webAPIResponse.IsError = true;
                    webAPIResponse.Message = "The Id name field is required ";
                    return BadRequest(webAPIResponse);
                }
                response = ManageInventoryDA.getInventoryBasedOnId(inventoryId);
                if (response.Status == 0)
                {
                    webAPIResponse.IsError = true;
                    webAPIResponse.Message = response.Message;

                    return BadRequest(webAPIResponse);

                }
                else
                {
                    webAPIResponse.IsError = false;
                    webAPIResponse.Message = response.Message;
                    webAPIResponse.Record = response.Record;
                    return Ok(webAPIResponse);
                }
            }
            catch (Exception ex)
            {
                webAPIResponse.IsError = false;
                webAPIResponse.Message = "Something went wrong";
                return BadRequest(webAPIResponse);
            }

        }

        /// <summary>
        /// Update item by inventory Id
        /// </summary>
        /// <param name="InventoryMaster"></param>
        /// <returns></returns>
        [ApiKeyAuth(2)]//"authkey: Storemanagement"
        [HttpPut("manager/Store/v{version:apiVersion}/ManageInventory/update")]
        [SwaggerResponse(204, "All operations in the put document succeeded.")]
        [SwaggerResponse(400, "The request could not be processed by the server. This may be due to malformed syntax or a semantic error (e.g., they failed validation for length, range, etc.). Check your parameters and retry.")]
        [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
        [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
        [SwaggerResponse(404, "The requested entity was not found.")]
        [SwaggerResponse(422, "The server understands the content type of the request entity, but it was unable to process the contained instructions.")]
        public async Task<IActionResult> UpdateInventoryMaster([FromBody] InventoryMaster InventoryMaster)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Responses response =  ManageInventoryDA.updateInventoryDetails(InventoryMaster);

            if (response.Status == 0)
            {
                webAPIResponse.IsError = true;
                webAPIResponse.Message = response.Message;
                return BadRequest(webAPIResponse);

            }
            else
            {
                webAPIResponse.IsError = false;
                webAPIResponse.Message = response.Message;
                return Ok(webAPIResponse);
            }

        }

        /// <summary>
        /// Generate bill and check for discount and rewards.
        /// </summary>
        /// <param name="InventoryMaster"></param>
        /// <returns></returns>
        [ApiKeyAuth(2)]//"authkey: Storemanagement"
        [HttpPost("manager/Store/v{version:apiVersion}/ManageInventory/Billing")]
        [SwaggerResponse(204, "All operations in the succeeded.")]
        [SwaggerResponse(400, "The request could not be processed by the server. This may be due to malformed syntax or a semantic error (e.g., they failed validation for length, range, etc.). Check your parameters and retry.")]
        [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
        [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
        [SwaggerResponse(404, "The requested entity was not found.")]
        [SwaggerResponse(422, "The server understands the content type of the request entity, but it was unable to process the contained instructions.")]
        public async Task<IActionResult> GenerateBill([FromBody] BilllingItem InventoryMaster)
        {
            BilllingItem response = ManageInventoryDA.CalculateBill(InventoryMaster);

                var data = new PdfDocument();
                string htmlContent = "<div style='margin: 20px auto; max-width: 600px; padding: 20px; border: 1px solid #ccc; background-color: #FFFFFF; font-family: Arial, sans-serif;'>";
                htmlContent += "<div style='margin-bottom: 20px; text-align: center;'>";
                htmlContent += "</div>";
                htmlContent += "<p style='margin: 0;'>New Look Store Management</p>";
                htmlContent += "<p style='margin: 0;'>New street</p>";
                htmlContent += "<p style='margin: 0;'>Phone: 123-456-7890</p>";
                htmlContent += "<p style='margin: 0;'>bnaglore</p>";
                htmlContent += "<div style='text-align: center; margin-bottom: 20px;'>";
                htmlContent += "<h1>Bill Details</h1>";
                htmlContent += "</div>";
                htmlContent += "<h3>Customer Details:</h3>";
                htmlContent += "<p> Name:" + response.CustomerName + "</p>";
                htmlContent += "<p> STD:" + response.CustomerId + "</p>";
                htmlContent += "<table style = 'width: 100%; border-collapse: collapse;'>";
                htmlContent += "<thead>";
                htmlContent += "<tr>";
                htmlContent += "<th style = 'padding: 8px; text-align: left; border-bottom: 1px solid #ddd;' > Fee Description </th>";
                htmlContent += "<th style = 'padding: 8px; text-align: left; border-bottom: 1px solid #ddd;' > Amount(INR) </th>";
                htmlContent += "</tr><hr/>";
                htmlContent += "</thead>";
                htmlContent += "<tbody>";
                htmlContent += "<tr>";
                htmlContent += "<td style = 'padding: 8px; text-align: left; border-bottom: 1px solid #ddd;' >" + response.InventoryName + " </td>";
                htmlContent += "<td style = 'padding: 8px; text-align: left; border-bottom: 1px solid #ddd;' >Rs " + response.Price + "/- </td>";
                htmlContent += "</tr>";
                    htmlContent += "</tbody>";
                    htmlContent += "<tfoot>";
                    htmlContent += "<tr>";
                    htmlContent += "<td style = 'padding: 8px; text-align: right; font-weight: bold;'> Total:</td>";
                    htmlContent += "<td style = 'padding: 8px; text-align: left; border-top: 1px solid #ddd;' >Rs" + response.Total + "/- </td>";
                    htmlContent += "</tr>";
                    htmlContent += "</tfoot>";
                //}
                htmlContent += "</table>";
                htmlContent += "</div>";

            PdfDocument pdf = PdfGenerator.GeneratePdf(htmlContent, (PdfSharp.PageSize)5);
                byte[]? response1 = null;
                using (MemoryStream ms = new MemoryStream())
                {
                    data.Save(ms);
                    response1 = ms.ToArray();
                }
                string fileName = "Bill" + DateTime.Now + ".pdf";
                return File(response1, "application/pdf", fileName);

        }
    }
}

