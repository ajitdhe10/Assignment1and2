﻿//using LF.CommonCore.DataAccess;
//using LF.PREMain.DataAccessCore;
using SM.Main.WEBAPICORE.ModelCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
using SM.Main.WEBAPICORE.Services;
using Swashbuckle.Swagger;
using Microsoft.AspNetCore.Mvc;

namespace SM.Main.WEBAPICORE.BusinessLogicCore
{
    /// <summary>
    /// Stub/Memory Repository
    /// </summary>
    public class StubManageInventoryDA : IManageInventoryDA
    {
        public static List<InventoryMaster> productService = new List<InventoryMaster>();
        public static List<CustomerDetails> customerDetailsService = new List<CustomerDetails>();
        public static List<BilllingItem> billlingItemService = new List<BilllingItem>();
        public static List<CategoryMaster> categoryMasterService = new List<CategoryMaster>();

        public StubManageInventoryDA() {


            customerDetailsService.Add(new CustomerDetails()
            {
                 CustId= 201,
                Name = "A",
                RewardPoints = 10,
                CategoryBasedDiscount = true,
                PurchaseAmountBasedDiscount = true,
                RegistedCustomer = true
            });

            customerDetailsService.Add(new CustomerDetails()
            {
                CustId = 202,
                Name = "B",
                RewardPoints = 10,
                CategoryBasedDiscount = false,
                PurchaseAmountBasedDiscount = true,
                 RegistedCustomer = true
            }) ;

            productService.Add(new InventoryMaster()
            {
                ItemName = "Dell Servers",
                StockQty = 5000,
                CategoryID= 1,
                InventoryID= 101,
                Price=2
            });
            productService.Add(new InventoryMaster()
            {
                ItemName = "Dell laptop",
                StockQty = 5000,
                CategoryID = 2,
                InventoryID = 102,
                Price = 2
            });
            productService.Add(new InventoryMaster()
            {
                ItemName = "Dell bag",
                StockQty = 5000,
                CategoryID = 3,
                InventoryID = 103,
                Price = 2
            });

            billlingItemService.Add(new BilllingItem()
            {
                 CategoryId= 1,
                InventoryId = 101,
                InventoryName = "laptop",
                Price = 2,
                Quantity = 1,
                CustomerId= 201,
                RewardPoints= 10,
                CategoryBasedDiscount=20,
                PurchaseAmountBasedDiscount=30
            });

            categoryMasterService.Add(new CategoryMaster()
            {
                CategoryID= 1,
                CategoryName="C1",
                CategoryBasedDiscount=true

            });
            categoryMasterService.Add(new CategoryMaster()
            {
                CategoryID = 2,
                CategoryName = "C2",
                CategoryBasedDiscount = true
            });
            categoryMasterService.Add(new CategoryMaster()
            {
                CategoryID = 3,
                CategoryName = "C3",
                CategoryBasedDiscount = false
            });
        }

        public BilllingItem CalculateBill(BilllingItem objModel)
        {
            Responses response = new Responses();
            BilllingItem bill = new BilllingItem();
            try
            {
                var categitem = (from pro in categoryMasterService
                                 where pro.CategoryID == objModel.CategoryId
                                 select pro).FirstOrDefault();

                var customer = (from pro in customerDetailsService
                                where pro.CustId == objModel.CustomerId
                                select pro).FirstOrDefault();
                var invetetoryItem = (from pro in productService
                            where pro.InventoryID == objModel.InventoryId
                            select pro).FirstOrDefault();

                if (customer != null)
                {
                    objModel.Total = objModel.Quantity * invetetoryItem.Price;

                    if (customer.RegistedCustomer == true)
                    {
                        objModel.RewardPoints= objModel.Quantity * 10;
                    }

                    if(categitem.CategoryID== objModel.CategoryId && categitem.CategoryBasedDiscount == true && customer.CategoryBasedDiscount==true)
                    {
                        objModel.CategoryBasedDiscount = 10;
                        objModel.Total = objModel.Total - 10;
                    }

                    if (customer.PurchaseAmountBasedDiscount==true && objModel.Total>1000)
                    {
                        objModel.CategoryBasedDiscount = 100;
                        objModel.Total = objModel.Total - 10;
                    }

                    billlingItemService.Add(objModel);
                    response.Status = 1;
                    response.Record = objModel;
                    response.Message = "Billing Successfully";
                }
                else
                {

                    objModel.Total = objModel.Quantity * invetetoryItem.Price;
                    if (categitem.CategoryID == objModel.CategoryId && categitem.CategoryBasedDiscount == true)
                    {
                        objModel.CategoryBasedDiscount = 5;
                        objModel.Total = objModel.Total - 5;
                    }

                    if (objModel.Total > 1000)
                    {
                        objModel.CategoryBasedDiscount = 50;
                        objModel.Total = objModel.Total - 50;
                    }

                    billlingItemService.Add(objModel);
                    response.Status = 1;
                    response.Record = objModel;
                    response.Message = "Billing Successfully";
                }
            }
            catch (Exception ex)
            {
                response.Status = 0;
                response.Message = "exception";
            }
            return objModel;
        }

        
        public Responses updateInventoryDetails(InventoryMaster objModel)
        {
            Responses response = new Responses();
            try
            {
               var item = (from pro in productService
                            where pro.InventoryID == objModel.InventoryID
                            select pro).FirstOrDefault();
                if (item != null)
                {
                    productService.Remove(item);
                    productService.Add(objModel);
                    response.Status = 1;
                    response.Message = "Updated Successfully";
                }
                else
                {
                    response.Status = 0;
                    response.Message = "Item Id do not exists";

                }
            }
            catch (Exception ex)
            {
                response.Status = 0;
                response.Message = "Item Id do not exists";
            }
            return response;
        }

        /// <summary>
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public Responses getInventoryBasedOnCatogory(int id)
        {
            List<InventoryMaster> objModel = new List<InventoryMaster>();
            Responses response = new Responses();
            try
            {
               if (productService.Count > 0)
                        {

                    objModel = (from pro in productService
                          where pro.CategoryID== id
                          select pro).ToList();

                    response.Status = 1;
                            response.Message = "Success";
                            response.Record = objModel;
                        }
                        else
                        {
                            objModel = null;
                            response.Status = 0;
                            response.Message = "Data does not match";
                            response.Record = objModel;

                        }
            }
            catch (Exception ex)
            {
                objModel = null;
                response.Status = 0;
                response.Message = ex.ToString();
                response.Record = objModel;
            }
            return response;
        }

        public Responses getInventoryBasedOnId(int id)
        {
            InventoryMaster objModel = new InventoryMaster();
            Responses response = new Responses();
            try
            {
                if (productService.Count > 0)
                {

                    objModel = (from pro in productService
                                where pro.InventoryID == id
                                select pro).FirstOrDefault();

                    response.Status = 1;
                    response.Message = "Success";
                    response.Record = objModel;
                }
                else
                {
                    objModel = null;
                    response.Status = 0;
                    response.Message = "Data does not match";
                    response.Record = objModel;

                }
            }
            catch (Exception ex)
            {
                objModel = null;
                response.Status = 0;
                response.Message = ex.ToString();
                response.Record = objModel;
            }
            return response;
        }
    }
}
