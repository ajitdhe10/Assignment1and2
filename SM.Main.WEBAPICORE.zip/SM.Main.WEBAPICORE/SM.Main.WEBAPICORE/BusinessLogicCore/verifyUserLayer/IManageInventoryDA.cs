﻿using SM.Main.WEBAPICORE.ModelCore;

namespace SM.Main.WEBAPICORE.Services
{
    public interface IManageInventoryDA
    {
        Responses updateInventoryDetails( InventoryMaster objmodel);
        Responses getInventoryBasedOnCatogory(int id);
        Responses getInventoryBasedOnId(int id);
        BilllingItem CalculateBill(BilllingItem billlingItem);
    }
}
