﻿using SM.Main.WEBAPICORE.ModelCore;
using SM.Main.WEBAPICORE.Services;
using System.Data;
using System.Data.SqlClient;

namespace SM.Main.WEBAPICORE.BusinessLogicCore
{
    public class ManageInventoryDA: IManageInventoryDA
    {
        /// <summary>
        /// Verify user keys and username,password
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public Responses updateInventoryDetails(InventoryMaster objModel)
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";
            Responses response = new Responses();
            DataSet objDT1 = new DataSet();
            var objDT = new DataTable();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand SqlComm = new SqlCommand("UPDATE MyDataTable ('ItemName', 'StockQty', 'CategoryID') VALUES ('@ItemName', '@StockQty', '@CategoryID') WHERE InventoryID ='@InventoryID'", con);
                    SqlComm.Parameters.AddWithValue("@InventoryID", objModel.InventoryID);
                    SqlComm.Parameters.AddWithValue("@ItemName", objModel.ItemName);
                    SqlComm.Parameters.AddWithValue("@StockQty", objModel.StockQty);
                    SqlComm.Parameters.AddWithValue("@CategoryID", objModel.CategoryID);
                    SqlComm.ExecuteNonQuery();
                    response.Status = 1;
                    response.Message = "Updated Successfully";
                }
            }
            catch (Exception ex)
            {
                response.Status = 0;
                response.Message = "Item Id do not exists";
            }
            return response;
        }

        /// <summary>
        /// Verify username,password
        /// response: accessToken model .
        /// Date:18-15-2020
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public Responses getInventoryBasedOnCatogory(int id)
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";
            DataSet objDT1 = new DataSet();
            var objDT = new DataTable();
            List<InventoryMaster> objModel = new List<InventoryMaster>();
            Responses response = new Responses();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("getInventoryDetails"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@CategoryID", SqlDbType.VarChar).Value = id;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            objDT.Load(cmd.ExecuteReader());
                            con.Close();
                        }
                        if (objDT != null)
                        {
                            if (objDT.Rows.Count > 0)
                            {
                                objModel = (from DataRow dr in objDT.Rows
                                               select new InventoryMaster()
                                               {
                                                   InventoryID = Convert.ToInt32(dr["InventoryID"]),
                                                   ItemName = dr["ItemName"].ToString(),
                                                   StockQty = Convert.ToInt32(dr["StockQty"]),
                                               }).ToList();
                            }
                            else
                                objModel = null;
                        }
                        else
                            objModel =null;

                        if (objModel.Count > 0)
                        {
                            response.Status = 1;
                            response.Message = "Success";
                            response.Record = objModel;
                        }
                        else
                        {
                            objModel = null;
                            response.Status = 0;
                            response.Message = "Data does not match";
                            response.Record = objModel;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objModel = null;
                response.Status = 0;
                response.Message = ex.ToString();
                response.Record = objModel;
            }
            return response;
        }

        /// <summary>
        /// implementated in Stub data repository
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public Responses getInventoryBasedOnId(int id)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// implementated in Stub data repository
        /// </summary>
        /// <param name="billlingItem"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public BilllingItem CalculateBill(BilllingItem billlingItem)
        {
            throw new NotImplementedException();
        }
    }
}
