﻿using SM.Main.WEBAPICORE.ModelCore;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace SM.Main.WEBAPICORE.BusinessLogicCore
{
    public class VerifyUserDA 
    {
        /// <summary>
        /// Verify user keys and username,password
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public UserModel verifyuserKey(UserModel objUserModel)
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";

            DataSet objDT1 = new DataSet();
            var objDT = new DataTable();
            try
            {

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("API_User_Verify"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@CustomerSecretKey", SqlDbType.VarChar).Value = objUserModel.CustomerSecret;
                        //cmd.Parameters.Add("@APIKey", SqlDbType.VarChar).Value = APIKey; cmd.Parameters.Add("@APIApplicationId", SqlDbType.VarChar).Value = APIApplicationId;
                        cmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = objUserModel.UserName;
                        cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = objUserModel.Password;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            objDT.Load(cmd.ExecuteReader());
                            con.Close();
                        }
                        if (objDT != null)
                        {
                            if (objDT.Rows.Count > 0)
                            {
                                objUserModel.UserId = int.Parse(objDT.Rows[0]["Id"].ToString());
                                if (objUserModel.UserId > 0)
                                {
                                    objUserModel.Message = objDT.Rows[0]["SUCCESS"].ToString();
                                }
                                else
                                {
                                    objUserModel.Message = objDT.Rows[0]["RESULTMESSAGE"].ToString();
                                }
                            }
                            else
                                objUserModel.UserId = 0;
                        }
                        else
                            objUserModel.UserId = 0;
                    }
                }
            }
            catch (Exception ex)
            { }
            return objUserModel;
        }

        /// <summary>
        /// generate access toeken.
        /// response: accessToken model .
        /// Date:18-15-2020
        /// By:Ajit Dhemar
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public UserModel getAccessToken(UserModel objUserModel, string UserId,string CustomerSecretKey )
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";

            string PE_SecurityKey = "Default API Service Security Key";
            var objDT = new DataTable();
            try
            {
                //CompanyExtras Selectedrow = (from x in objDBContext.CompanyExtras
                //                             where x.CustomerSecretKey == CustomerSecretKey
                //                             select x).FirstOrDefault();
                //if (Selectedrow.EncryptionKey != null)
                //{
                //    PE_SecurityKey = Selectedrow.EncryptionKey;
                //}

                Random random = new Random();
                int rInt = random.Next(0, 20); //for ints
                string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+][{}";
                string lblUserUniqueId = new string(Enumerable.Repeat(chars, rInt)
                    .Select(s => s[random.Next(s.Length)]).ToArray());

                string ency = subEncryption(lblUserUniqueId,
                                               PE_SecurityKey.ToString().Trim(), true);
                string encysecret = subEncryption(objUserModel.CustomerSecret.ToString().Trim(),
                                               PE_SecurityKey.ToString().Trim(), true);

                string accessToken = ency.Replace("=", "") + "" + encysecret.Replace("=", "");

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("API_User_AccessTokenUpdate"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Employee_Id", SqlDbType.Int).Value =UserId;
                        cmd.Parameters.Add("@CustomerSecretKey", SqlDbType.VarChar).Value = CustomerSecretKey;
                        cmd.Parameters.Add("@AccessToken", SqlDbType.VarChar).Value = accessToken;
                        cmd.Parameters.Add("@AccessTokenTail", SqlDbType.VarChar).Value = encysecret.Trim();
                        cmd.Parameters.Add("@AccessTokenOriginal", SqlDbType.VarChar).Value = lblUserUniqueId.Trim();
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            objDT.Load(cmd.ExecuteReader());
                            con.Close();
                        }
                        if (objDT!= null)
                        {
                            if (objDT.Rows.Count > 0)
                            {
                                objUserModel.UserId = int.Parse(objDT.Rows[0]["Id"].ToString());
                                if (objUserModel.UserId > 0)
                                {
                                    objUserModel.accessToken = accessToken;
                                    objUserModel.accessTokenCounter = int.Parse(objDT.Rows[0]["tokenCounter"].ToString());
                                    objUserModel.accessTokenExpiresIn = int.Parse(objDT.Rows[0]["AccesstokenExpiresMins"].ToString());
                                }
                                else
                                {
                                    objUserModel.Message = objDT.Rows[0]["RESULTMESSAGE"].ToString();
                                }
                            }
                            else
                                objUserModel.UserId = 0;
                        }
                        else
                            objUserModel.UserId = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                string exception;
                exception = ex.ToString();
            }
            return objUserModel;
        }


        /// <summary>
        /// Verify user keys and username,password
        /// response: accessToken model .
        /// Date:18-15-2020
        /// By:Ajit Dhemar
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public UserModel verifyAccessToken(UserModel objUserModel)
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";
            DataSet objDT1 = new DataSet();
            var objDT = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("API_User_AccessTokenVerify"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@AccessToken", SqlDbType.VarChar).Value = objUserModel.accessToken;
                        cmd.Parameters.Add("@AccessTokenCounter", SqlDbType.VarChar).Value = 0;
                        //cmd.Parameters.Add("@CustomerSecretKey", SqlDbType.VarChar).Value = CustomerKey;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            objDT.Load(cmd.ExecuteReader());
                            con.Close();
                        }
                        if (objDT != null)
                        {
                            if (objDT.Rows.Count > 0)
                            {
                                objUserModel.UserId = int.Parse(objDT.Rows[0]["Id"].ToString());
                            }
                            else
                                objUserModel.UserId = 0;
                            objUserModel.Message = objDT.Rows[0]["RESULTMESSAGE"].ToString();
                        }
                        else
                            objUserModel.UserId = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                string exception;
                exception = ex.ToString();
            }
            return objUserModel;
        }


        /// <summary>
        /// Verify username,password
        /// response: accessToken model .
        /// Date:18-15-2020
        /// </summary>
        /// <param name="objUserModel"></param>
        /// <returns>objUserModel</returns>
        public UserModel VerifyUserNamePassword(UserModel objUserModel)
        {
            string connectionString = "Server=LAPTOP-6P5NK25R\\SQLSERVER2022DEV;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;";
            DataSet objDT1 = new DataSet();
            var objDT = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("WebUser_Verify"))
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                       //cmd.Parameters.Add("@CustomerSecretKey", SqlDbType.VarChar).Value = objUserModel.CustomerSecret;
                        //cmd.Parameters.Add("@APIKey", SqlDbType.VarChar).Value = APIKey; cmd.Parameters.Add("@APIApplicationId", SqlDbType.VarChar).Value = APIApplicationId;
                        cmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = objUserModel.UserName;
                        cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = objUserModel.Password;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            objDT.Load(cmd.ExecuteReader());
                            con.Close();
                        }
                        if (objDT != null)
                        {
                            if (objDT.Rows.Count > 0)
                            {
                                objUserModel.UserId = int.Parse(objDT.Rows[0]["Id"].ToString());
                                if (objUserModel.UserId > 0)
                                {
                                    objUserModel.CustomerSecret = objDT.Rows[0]["CustomerSecretKey"].ToString();
                                }
                                else
                                {
                                    objUserModel.Message = objDT.Rows[0]["RESULTMESSAGE"].ToString();
                                }
                            }
                            else
                                objUserModel.UserId = 0;
                        }
                        else
                            objUserModel.UserId = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                string exception;
                exception = ex.ToString();
            }
            return objUserModel;
        }

        public static string subEncryption(string strTextToEncrypt, string strKeyValue, bool IsHasing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(strTextToEncrypt);


            string key = strKeyValue;// (string)settingsReader.GetValue(strKeyValue,
                                     //         typeof(String));
            if (IsHasing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray =
              cTransform.TransformFinalBlock(toEncryptArray, 0,
              toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public static string subDecryprtion(string strTextToDecrypt, string strKeyValue, bool IsHasing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(strTextToDecrypt);

            string key = strKeyValue;// (string)settingsReader.GetValue(strKeyValue, typeof(String));

            if (IsHasing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
    }
}
