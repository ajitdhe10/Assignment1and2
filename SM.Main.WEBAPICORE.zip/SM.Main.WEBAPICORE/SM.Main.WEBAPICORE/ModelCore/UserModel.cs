﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SM.Main.WEBAPICORE.ModelCore
{
    public class UserModel
    {
        public int UserId { get; set; }
        public string CustomerSecret { get; set; }
        public string ApplicationKey { get; set; }
        public string ServiceKey { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Message { get; set; }
        public string accessToken { get; set; }
        public int accessTokenExpiresIn { get; set; }
        public int accessTokenCounter { get; set; }
    }
}
