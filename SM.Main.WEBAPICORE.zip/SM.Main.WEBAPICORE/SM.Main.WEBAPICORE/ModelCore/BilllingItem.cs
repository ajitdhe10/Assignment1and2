﻿using System.Buffers.Text;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SM.Main.WEBAPICORE.ModelCore
{
    public class BilllingItem
    {
        public int CategoryId { get; set; }
        public int InventoryId { get; set; }
        public string InventoryName { get; set; }
        public string CustomerName { get; set; }
        public int Price { get; set; }
        public double Total { get; set; }
        public int Quantity { get; set; }
        public int CustomerId { get; set; }
        public int RewardPoints { get; set; }
        public int CategoryBasedDiscount { get; set; }
        public int PurchaseAmountBasedDiscount { get; set; }
    }
}
