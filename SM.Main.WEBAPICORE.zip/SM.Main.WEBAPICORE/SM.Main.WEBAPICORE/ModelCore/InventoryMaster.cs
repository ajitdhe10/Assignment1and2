﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SM.Main.WEBAPICORE.ModelCore
{
    public class InventoryMaster
    {
        [Key]
        public int InventoryID { get; set; }

        [Required]
        [Display(Name = "ItemName")]
        public string ItemName { get; set; }

        [Required]
        [Display(Name = "StockQty")]
        public int StockQty { get; set; }

        [Required]
        [Display(Name = "Price")]
        public int Price { get; set; }

        public int CategoryID { get; set; }
    }
}
