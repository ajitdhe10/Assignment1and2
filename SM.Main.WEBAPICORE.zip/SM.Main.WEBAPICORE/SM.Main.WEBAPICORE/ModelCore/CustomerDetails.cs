﻿using System.Buffers.Text;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SM.Main.WEBAPICORE.ModelCore
{
    public class CustomerDetails
    {
        public int CustId { get; set; }
        public string Name { get; set; }
        public int RewardPoints { get; set; }
        public bool CategoryBasedDiscount { get; set; }
        public bool PurchaseAmountBasedDiscount { get; set; }
        public bool RegistedCustomer { get; set; }
    }
}
